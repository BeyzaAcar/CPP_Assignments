#include "AbstractTetris.hpp"

using namespace std;

AbstractTetris::AbstractTetris(){}
AbstractTetris::~AbstractTetris(){}



